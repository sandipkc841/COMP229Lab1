﻿using COMP229_FinalTerm.Models;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace COMP229_FinalTerm
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        // ==================
        // ADD YOUR CODE HERE
        // ==================
        // Q1.4


        // ================== 
        private string _filename = "";

        public MainWindow()
        {
            InitializeComponent();
            // ==================
            // ADD YOUR CODE HERE
            // ==================
            // Q1.5


            // ================== 
        }


        private void btnLoadFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Multiselect = false;
            openFileDialog.Filter = "CSV files (*.csv)|*.csv";
            if (openFileDialog.ShowDialog() == true)
            {
                _filename = openFileDialog.FileName;
                txtFileLoaded.Text = _filename;               
            }             
        }

        private void btnInsertData_Click(object sender, RoutedEventArgs e)
        {
            // Runs insertDataIntoDatabase() in another thread and notifies the ProgressBar.
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += insertDataIntoDatabase;
            worker.ProgressChanged += worker_ProgressChanged;

            worker.RunWorkerAsync();
        }

        private void insertDataIntoDatabase(object sender, DoWorkEventArgs e) 
        {
            try
            {
                (sender as BackgroundWorker).ReportProgress(10);
                string[] lines = File.ReadAllLines(System.IO.Path.ChangeExtension(_filename, ".csv"));
                                
                string[] columns = lines[0].Split(',');
                                
                (sender as BackgroundWorker).ReportProgress(20);

                // Inserts Provinces
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] cell = lines[i].Split(',');

                    Province? province = _dbContext.Provinces.FirstOrDefault(
                        c => c.ProvinceName == cell[0] &
                        c.CountryName == cell[1]);

                    if (province == null)
                    {
                        province = new()
                        {
                            ProvinceName = cell[0],
                            Latitude = cell[2] != "" ? Convert.ToDouble(cell[2]) : 0,
                            Longitude = cell[3] != "" ? Convert.ToDouble(cell[3]) : 0,
                            CountryName = cell[1],
                        };
                        _dbContext.Provinces.Add(province);
                        _dbContext.SaveChanges();
                    }
                }

                // Notifies the progress bar
                (sender as BackgroundWorker).ReportProgress(40);


                // Inserts Cases Reports
                for (int i = 1; i < lines.Length; i++)
                {
                    string[] cell = lines[i].Split(',');

                    // ==================
                    // ADD YOUR CODE HERE
                    // ==================
                    // Q2.1


                    // ================== 

                    //  Inserts Cases Data                
                    for (int j = 4; j < columns.Length; j++)
                    {
                        int amount = Convert.ToInt32(cell[j]);
                        // ==================
                        // ADD YOUR CODE HERE
                        // ==================
                        // Q2.1 and Q2.2


                        // ================== 
                    }
                }

                // Notifies the progress bar
                (sender as BackgroundWorker).ReportProgress(80);


                // Saves the final changes
                // ==================
                // ADD YOUR CODE HERE
                // ==================
                // Q2.3


                // ==================


                // Notifies the progress bar
                (sender as BackgroundWorker).ReportProgress(100);                
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            pbInsertDb.Value = e.ProgressPercentage;

            if (e.ProgressPercentage == 100)
            {
                txtBar.Text = "Completed";
                MessageBox.Show("All data has been inserted successfully into the database.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }            
        }

        private void btnLoadCountries_Click(object sender, RoutedEventArgs e)
        {
            var countries = (from p in _dbContext.Provinces
                             select p.CountryName)
                           .Distinct()
                           .ToList();

            cbCountries.ItemsSource = countries;

            MessageBox.Show("All countires has been loaded successfully.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void cbCountries_DropDownClosed(object sender, EventArgs e)
        {
            cbGroupResult.IsChecked = false;
            if (cbCountries.SelectedItem != null)
            {
                try
                {
                    // ==================
                    // ADD YOUR CODE HERE
                    // ==================
                    // Q3.2



                    // ==================




                    // ==================
                    // ADD YOUR CODE HERE
                    // ==================
                    // Q3.3


                    // ==================

                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void cbProvinces_DropDownClosed(object sender, EventArgs e)
        {
            cbGroupResult.IsChecked = false;
            if (cbProvinces.SelectedItem != null)
                try
                {
                    // ==================
                    // ADD YOUR CODE HERE
                    // ==================
                    // Q3.4



                    // ==================
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
        }

        private void cbGroupResult_Checked(object sender, RoutedEventArgs e)
        {
            if (cbProvinces.SelectedItem != null)
                try
                {
                    // ==================
                    // ADD YOUR CODE HERE
                    // ==================
                    // Q3.5


                    // ==================
                }
                catch (Exception exc)
                {
                    MessageBox.Show(exc.Message, "Erro", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            else { 
                cbGroupResult.IsChecked = false; 
                MessageBox.Show("Please, select one province.", "Info", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

        }
    }
}
