﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace COMP229_FinalTerm.Models
{
    public class AppDbContext
    {
        // ==================
        // ADD YOUR CODE HERE
        // ==================
        // Q1.2


        // ==================  
    }
}
